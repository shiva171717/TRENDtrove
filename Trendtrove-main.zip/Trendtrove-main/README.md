# E-CommerceWebsite
 A mobile responsive sample of E-Commerce Website using HTML, CSS, JavaScript and API's
 
 
 
### Home page
![Screenshot_31-5-2024_94017_127 0 0 1](https://github.com/jayanthmarupaka/Trendtrove/assets/95174580/0aa16c0e-5572-40c3-888b-2fd5c45d17bb)




